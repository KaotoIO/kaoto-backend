# camel-component-metadata
Kamelet-like metadata to use Apache Camel components on Kaoto
