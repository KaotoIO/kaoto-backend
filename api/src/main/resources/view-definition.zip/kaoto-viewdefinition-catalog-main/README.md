# Kaoto Catalog of View Definitions

Catalog of possible View Definitions to help the UI decide what to show on each case.
